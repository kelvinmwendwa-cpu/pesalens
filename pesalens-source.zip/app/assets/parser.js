(function(root){'use strict';
// Every amount is an integer in Kenya-shilling cents. No tariff is inferred.
const M='(?:Kshs?\\.?|KES)\\s*([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]{1,2})?)';
const kinds={payment:'Payment / money sent',receipt:'Money received',deposit:'Cash deposited',withdrawal:'Cash withdrawn',airtime:'Airtime',transferIn:'KCB / savings → M-Pesa',transferOut:'M-Pesa → KCB / savings',loanDraw:'Loan received',loanRepay:'Loan repayment',fulizaDraw:'Fuliza used',fulizaRepay:'Fuliza repayment',creditCharge:'Credit charge assessed',refund:'Refund / reversal received',reverseOut:'Reversal deducted',snapshot:'Balance / credit information',review:'Needs review'};
function cents(s){if(s===null||s===undefined)return null;let m=String(s).replace(/,/g,'').match(/^(\d+)(?:\.(\d{1,2}))?$/);if(!m)return null;let n=Number(m[1])*100+Number((m[2]||'').padEnd(2,'0'));return Number.isSafeInteger(n)&&n<=999999999999?n:null;}
function amount(s){let m=String(s||'').match(new RegExp(M,'i'));return m?cents(m[1]):null;}
function get(s,p){let m=s.match(new RegExp(p+M,'i'));return m?cents(m[1]):null;}
function before(s,tail){let m=s.match(new RegExp(M+tail,'i'));return m?cents(m[1]):null;}
function first(s,patterns){for(let p of patterns){let v=get(s,p);if(v!==null)return v}return null;}
function hash(s){let a=2166136261,b=3335557771;for(let c of s){a=Math.imul(a^c.charCodeAt(0),16777619);b=Math.imul(b^c.charCodeAt(0),2246822519)}return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');}
function norm(s){return String(s||'').replace(/[\u2010-\u2015]/g,'-').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
function dateOf(body,stamp){let dm=body.match(/(?:\bon\s+|\b(?:transaction\s+)?date\s*:\s*|^)(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})(?:\s+(?:at\s+)?(\d{1,2}):(\d{2})\s*(AM|PM)?)?/i);let date=Number(stamp)||Date.now(),dated=!!stamp,precise=!!stamp;if(dm){let y=+dm[3];if(y<100)y+=2000;let h=+(dm[4]||0);if(dm[6])h=h%12+(/pm/i.test(dm[6])?12:0);let d=new Date(y,+dm[2]-1,+dm[1],h,+(dm[5]||0));if(d.getMonth()===+dm[2]-1&&d.getDate()===+dm[1]&&h<24&&+(dm[5]||0)<60){dated=true;precise=!!stamp&&Math.abs(Number(stamp)-+d)<60000;date=precise?Number(stamp):+d;}}return {date,dated,precise};}
function parse(raw,stamp,sender=''){
 const body=norm(raw);if(!body||/\b(?:OTP|one.time password|verification code)\b/i.test(body))return null;
 let candidates=[(body.match(/^([A-Z0-9]{10})\b/i)||[])[1],(body.match(/(?:transaction|reference|ref)\s*(?:code|id|no\.?|number)?\s*[:#]?\s*([A-Z0-9]{10})\b/i)||[])[1]];let ref=candidates.find(r=>r&&/^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]{10}$/i.test(r))||'';
 const service=/fuliza/i.test(body)?'fuliza':/kcb\s*m[ -]?pesa/i.test(body+' '+sender)?'kcb':/m[ -]?shwari/i.test(body+' '+sender)?'mshwari':'none';
 if(!ref&&service==='none')return null;if(amount(body)===null&&!/fully (?:repaid|settled)|cleared.*(?:loan|fuliza)/i.test(body))return null;
 let d=dateOf(body,stamp),t={id:'SMS'+hash(body+(!ref&&stamp&&!dateOf(body).dated?'|'+stamp:'')),sourceStamp:Number(stamp)||null,code:ref.toUpperCase(),body,date:d.date,dated:d.dated,precise:d.precise,sender:String(sender),service,debtService:service,kind:'review',type:'review',label:kinds.review,who:'Unrecognised message',amount:0,fee:0,feeKnown:false,creditCharge:0,balance:null,debtBalance:null,savingsBalance:null,availableCredit:null,walletProceeds:null,draw:0,repay:0,account:'wallet',category:'Other',note:'',manual:false,excluded:false,reason:''};
 const fee=first(body,['transaction\\s+cost\\s*[,.:]?\\s*','transaction\\s+(?:fee|charge)(?:s)?\\s*(?:is|of|:)?\\s*']);t.feeKnown=fee!==null;t.fee=fee||0;
 // A KCB/M-Shwari account balance is never a wallet balance.
 t.balance=first(body,['(?:new\\s+)?(?<!KCB )(?<!KCB-)(?<!Fuliza )M[ -]?PESA\\s+(?:account\\s+)?balance(?:\\s+is)?\\s*[:=]?\\s*']);
 if(/(?:new\s+)?KCB\s+M[ -]?PESA\s+(?:account\s+)?balance/i.test(body)){
  const all=[...body.matchAll(new RegExp('(?:new\\s+)?M[ -]?PESA\\s+(?:account\\s+)?balance(?:\\s+is)?\\s*[:=]?\\s*'+M,'ig'))];t.balance=null;for(const m of all){let prefix=body.slice(Math.max(0,m.index-9),m.index);if(!/KCB\s*$/i.test(prefix)&&!/Fuliza\s*$/i.test(prefix))t.balance=cents(m[1]);}
 }
 t.savingsBalance=first(body,['KCB\\s+M[ -]?PESA\\s+(?:savings\\s+|account\\s+)?balance(?:\\s+is)?\\s*[:=]?\\s*','M[ -]?Shwari\\s+(?:savings\\s+|account\\s+)?balance(?:\\s+is)?\\s*[:=]?\\s*']);
 t.debtBalance=first(body,['(?:total\\s+)?outstanding\\s+(?:(?:Fuliza|KCB\\s+M[ -]?PESA|M[ -]?Shwari)\\s+)?(?:loan\\s+)?(?:amount|balance|debt)(?:\\s+(?:is|of))?\\s*[:=]?\\s*','(?:Fuliza|loan)\\s+(?:outstanding\\s+)?balance(?:\\s+is)?\\s*[:=]?\\s*','(?:total\\s+)?(?:amount\\s+due|loan\\s+due|loan\\s+repayable)(?:\\s+is)?\\s*[:=]?\\s*']);
 if(/(?:loan|fuliza).*(?:fully repaid|fully settled)|(?:fully repaid|fully settled).*(?:loan|fuliza)/i.test(body)&&!/(?:not|isn't|is not)\s+fully/i.test(body))t.debtBalance=0;
 t.availableCredit=first(body,['available\\s+(?:Fuliza\\s+)?(?:limit|credit)(?:\\s+is)?\\s*[:=]?\\s*']);
 const chargeTail='(?:\\s+(?:is|of|charged))?\\s*[,.:]?\\s*';
 const chargeParts=['access\\s+fee','maintenance\\s+(?:fee|charge)','loan\\s+fee','(?:loan\\s+interest|interest\\s+charged)'].map(part=>first(body,[part+chargeTail])||0);
 t.creditCharge=first(body,['total\\s+(?:credit|loan|Fuliza)\\s+charges'+chargeTail])??chargeParts.reduce((a,b)=>a+b,0);

 let value=amount(body),k='review',who='',reason='This wording is not specific enough to classify automatically.';
 const failed=/\b(?:failed|unsuccessful|declined|cancelled|rejected|pending|request received)\b/i.test(body);
 const success=/\b(?:confirmed|successfully|received|repaid|recovered|deducted|disbursed|credited|paid|borrowed|used|withdrawn|transferred|deposited|charged)\b|Fuliza\s+M[ -]?PESA\s+amount\s+is/i.test(body);
 // Extract a transaction amount by its action, not by the first balance or limit.
 const pay=first(body,['withdraw(?:n)?\\s+'])??before(body,'\\s+(?:sent\\s+to|paid\\s+to|bought|purchased|withdrawn)\\b');
 const inValue=first(body,['(?:you\\s+(?:have\\s+)?)?received\\s+'])??before(body,'\\s+(?:has\\s+been\\s+|was\\s+)?received\\s+from');
 const matchedRepay=(body.match(new RegExp(M+'\\s+(?:has\\s+been\\s+|was\\s+)?(?:used\\s+to\\s+(?:(?:fully|partially)\\s+)?repay|repaid|deducted|recovered)','i'))||[])[1];
 const explicitRepay=first(body,['(?:used\\s+to\\s+(?:(?:fully|partially)\\s+)?repay|repaid|recovered|deducted)\\s+(?:an?\\s+amount\\s+of\\s+)?']);
 const repayAmount=matchedRepay?cents(matchedRepay):explicitRepay;
 const explicitDraw=first(body,['(?:Fuliza\\s+(?:M[ -]?PESA\\s+)?(?:amount|used)(?:\\s+(?:is|of))?|(?:you\\s+(?:have\\s+)?)?(?:used|borrowed|drawn))\\s*[:=]?\\s*']);
 const receipt=/\b(?:you\s+(?:have\s+)?)received\b/i.test(body);
 const paid=/\b(?:sent to|paid to|bought|purchased|withdraw(?:n)?\s+(?:Ksh|KES))/i.test(body);
 if(failed){reason='Failed, pending or declined message: no confirmed movement.';}
 else if(/(?:reversal|reversed|refund)/i.test(body)){
  if(/(?:received|credited|refunded|returned)\b/i.test(body)&&value!==null){k='refund';value=first(body,['(?:refund(?:ed)?|credited|received|returned)\\s+(?:of\\s+)?'])??before(body,'\\s+(?:has\\s+been\\s+)?(?:refunded|credited|received|returned)\\b');who='Refund / reversal';}
  else if(/(?:deducted|debited|withdrawn)\b/i.test(body)&&value!==null){k='reverseOut';value=first(body,['(?:deducted|debited|withdrawn)\\s+'])??before(body,'\\s+(?:has\\s+been\\s+)?(?:deducted|debited|withdrawn)\\b');who='Reversal deducted';}
  else reason='Reversal direction is unclear; confirm whether money returned or left.';
 }else if(receipt&&success){
  k='receipt';value=inValue;who=(body.match(/received\s+(?:Kshs?\.?|KES)\s*[\d,.]+\s+from\s+(.+?)(?:\s+on\s+\d|\.\s*(?:New|Your)|$)/i)||[])[1]||'Money received';
  if(/\bfrom\s+(?:KCB\s+M[ -]?PESA|M[ -]?SHWARI)/i.test(body)){k='transferIn';t.service=/kcb/i.test(body)?'kcb':'mshwari';}
  if(/\bfrom\s+Fuliza/i.test(body)){k='fulizaDraw';who='Fuliza overdraft used';}
  if(/\bloan\s+(?:disbursement|proceeds)\b/i.test(body)&&t.service!=='none'){k='loanDraw';t.account='wallet';}
  if(/fuliza/i.test(body)&&repayAmount!==null)t.repay=repayAmount;
 }else if(paid&&/confirmed/i.test(body)){
  value=pay;k=/withdraw/i.test(body)?'withdrawal':/bought|purchased/i.test(body)?'airtime':'payment';
  who=(body.match(/(?:sent to|paid to)\s+(.+?)(?:\s+on\s+\d|\s+for account|\.\s*(?:New|Your)|$)/i)||[])[1]||kinds[k];
  if(t.service==='fuliza'){
   if(explicitDraw!==null)t.draw=explicitDraw;
   // No guess that the entire payment was borrowed.
  }else if(t.service==='kcb'||t.service==='mshwari'){
   if(/(?:pay|repay|repayment|repaid)\s+(?:your\s+|the\s+)?(?:KCB\s+M[ -]?PESA\s+|M[ -]?SHWARI\s+)?loan|loan\s+(?:repay|repayment)|\b522559\b/i.test(body)){k='loanRepay';}
   else if(k==='payment'){k='transferOut';who=t.service==='kcb'?'KCB M-Pesa transfer':'M-Shwari transfer';}
  }
 }else if(t.service==='fuliza'&&repayAmount!==null&&success){k='fulizaRepay';value=repayAmount;who='Fuliza automatic repayment';}
 else if(t.service==='fuliza'&&explicitDraw!==null&&success){k='fulizaDraw';value=explicitDraw;who='Fuliza overdraft used';}
 else if((t.service==='kcb'||t.service==='mshwari')&&/\bloan\b/i.test(body)&&/\b(?:disbursed|credited|approved|borrowed)\b/i.test(body)&&!/(?:loan\s+limit|eligible|qualify)/i.test(body)){
  k='loanDraw';value=first(body,['loan\\s+(?:of\\s+|amount(?:\\s+is)?\\s*[:=]?\\s*)?','(?:disbursed|credited)\\s+(?:an?\\s+amount\\s+of\\s+)?'])??before(body,'\\s+(?:has\\s+been\\s+)?(?:disbursed|credited|loan)\\b');who=(t.service==='kcb'?'KCB M-Pesa':'M-Shwari')+' loan';
  t.account=/\b(?:to|into|in)\s+(?:your\s+)?M[ -]?PESA\s+(?:wallet|account)/i.test(body)?'wallet':'bank';
  if(/\bapproved\b/i.test(body)&&!/\b(?:disbursed|credited)\b/i.test(body)){k='review';reason='Loan approval does not prove disbursement. Confirm where the funds arrived.';}
 }else if((t.service==='kcb'||t.service==='mshwari')&&/\b(?:loan|repay)\b/i.test(body)&&(/\brepaid\b|loan\s+repayment\s+(?:of\s+)?(?:Ksh|KES)/i.test(body))){
  k='loanRepay';value=repayAmount??first(body,['loan\\s+repayment\\s+(?:of\\s+)?'])??before(body,'\\s+(?:loan\\s+)?repayment\\b');who='Loan repayment';
  t.account=/\bfrom\s+(?:your\s+)?M[ -]?PESA\s+(?:wallet|account)|\bM[ -]?PESA\s+(?:wallet|account)\s+(?:was\s+)?(?:debited|deducted)/i.test(body)?'wallet':/\bfrom\s+(?:your\s+)?(?:KCB\s+M[ -]?PESA|M[ -]?SHWARI)/i.test(body)?'bank':'unknown';
  if(t.account==='unknown'){k='review';reason='Repayment is confirmed, but the paying account is unclear. Select wallet or bank in the transaction.';}
 }else if((t.service==='kcb'||t.service==='mshwari')&&/withdrawn|transferred|deposited/i.test(body)){
  if(/\bto\s+(?:your\s+)?M[ -]?PESA(?:\s+(?:wallet|account))?\b/i.test(body)){k='transferIn';who='Savings transferred to M-Pesa';}
  else if(/\bfrom\s+(?:your\s+)?M[ -]?PESA\b|\bto\s+(?:your\s+)?(?:KCB\s+M[ -]?PESA|M[ -]?SHWARI)/i.test(body)){k='transferOut';who='M-Pesa transferred to savings';}
  value=first(body,['(?:withdrawn|transferred|deposited)\\s+(?:an?\\s+amount\\s+of\\s+)?'])??before(body,'\\s+(?:has\\s+been\\s+)?(?:withdrawn|transferred|deposited)\\b');
 }else if(t.service==='fuliza'&&t.creditCharge>0&&/charged|debited|assessed|added/i.test(body)){k='creditCharge';value=0;who='Fuliza charge added to debt';}
 else if(/\bdeposit\b|deposited|\bGive\s+(?:Ksh|KES)/i.test(body)&&/confirmed/i.test(body)){k='deposit';value=first(body,['Give\\s+','deposited\\s+'])??before(body,'\\s+deposited\\b');who='Agent cash deposit';}
 else if((t.debtBalance!==null||t.savingsBalance!==null||t.availableCredit!==null)&&!/\b(?:received|sent|paid|repay|borrowed|disbursed|deducted)\b/i.test(body)){k='snapshot';value=0;who='Account information';}
 if(!ref&&t.account==='wallet'&&['transferIn','transferOut','loanDraw','loanRepay'].includes(k)){k='review';reason='Bank wallet movement has no reference to link its M-Pesa confirmation. Confirm or exclude this acknowledgement to avoid counting it twice.';}
 if(k!=='review'&&k!=='snapshot'&&k!=='creditCharge'&&(!Number.isSafeInteger(value)||value<=0)){k='review';reason='A confirmed transaction amount could not be identified.';}
 if(k==='loanDraw'){t.walletProceeds=first(body,['net\\s+(?:loan\\s+)?(?:proceeds|amount)(?:\\s+is)?\\s*[:=]?\\s*','credited\\s+(?:with\\s+|an?\\s+amount\\s+of\\s+)?']);if(t.account==='wallet'&&t.walletProceeds===null&&/withheld|deducted\s+(?:upfront|in\s+advance)/i.test(body)){k='review';reason='Loan charges were withheld but the net wallet credit is unclear. Enter the actual wallet proceeds from the SMS.';}}
 t.kind=k;t.label=kinds[k];t.who=who||t.label;t.amount=value??0;t.reason=k==='review'?reason:'';
 if(k==='review')t.type='review';else if(['receipt','deposit','transferIn','refund'].includes(k)||(k==='loanDraw'&&t.account==='wallet'))t.type='in';else if(['payment','withdrawal','airtime','transferOut','fulizaRepay','reverseOut'].includes(k)||(k==='loanRepay'&&t.account==='wallet'))t.type='out';else t.type='info';
 t.category=['loanDraw','loanRepay','fulizaDraw','fulizaRepay','creditCharge'].includes(k)?'Credit':/transfer/.test(k)?'Savings transfer':k==='receipt'?'Income':k==='deposit'?'Cash deposit':k==='withdrawal'?'Cash withdrawal':k==='airtime'?'Airtime':k==='refund'?'Refund':/kplc|water|rent|dstv|zuku/i.test(t.who)?'Bills':/supermarket|naivas|quickmart|carrefour/i.test(t.who)?'Shopping':/hotel|restaurant|cafe|food/i.test(t.who)?'Food':'Other';
 return t;
}
function effects(t){
 const e={walletIn:0,walletOut:0,spend:0,fees:0,received:0,deposits:0,withdrawals:0,transferIn:0,transferOut:0,fulizaDraw:0,fulizaRepay:0,kcbDraw:0,kcbRepay:0,mshwariDraw:0,mshwariRepay:0,creditCharges:0,refunds:0,reversalOut:0,unknownFees:0};
 if(t.excluded||t.kind==='review')return e;
 const a=t.amount,f=t.fee;let k=t.kind;
 if(k==='payment'||k==='airtime'){e.walletOut=a;e.spend=a;}
 if(k==='receipt'){e.walletIn=a;e.received=a;}
 if(k==='deposit'){e.walletIn=a;e.deposits=a;}
 if(k==='withdrawal'){e.walletOut=a;e.withdrawals=a;}
 if(k==='transferIn'){e.walletIn=a;e.transferIn=a;}
 if(k==='transferOut'){e.walletOut=a;e.transferOut=a;}
 if(k==='refund'){e.walletIn=a;e.refunds=a;}
 if(k==='reverseOut'){e.walletOut=a;e.reversalOut=a;}
 if(k==='loanDraw'){if(t.account==='wallet')e.walletIn=t.walletProceeds??a;if(t.service==='kcb')e.kcbDraw=a;if(t.service==='mshwari')e.mshwariDraw=a;}
 if(k==='loanRepay'){if(t.account==='wallet')e.walletOut=a;if(t.service==='kcb')e.kcbRepay=a;if(t.service==='mshwari')e.mshwariRepay=a;}
 if(k==='fulizaDraw'){e.fulizaDraw=a;e.walletIn=a;}
 if(k==='fulizaRepay'){e.fulizaRepay=a;e.walletOut=a;}
 if(t.draw>0){e.fulizaDraw+=t.draw;e.walletIn+=t.draw;}
 if(t.repay>0){e.fulizaRepay+=t.repay;e.walletOut+=t.repay;}
 if(k!=='snapshot'){
  e.creditCharges=t.creditCharge||0;
  // Credit charges assessed to debt are not paid again from the wallet here.
  if(t.account==='wallet'&&k!=='creditCharge'){e.fees=f;e.walletOut+=f;e.spend+=f;if(!t.feeKnown)e.unknownFees=1;}
 }
 return e;
}
// Combine complementary notifications by exact reference and component. Never
// deduplicate a receipt against its repayment or a payment against its borrowing.
function ledger(rows){
 const used=new Map(),duplicates=[],conflicts=[],entries=[],blocked=new Set();
 let sorted=[...rows].sort((a,b)=>Number(b.manual)-Number(a.manual)||Number(b.feeKnown)-Number(a.feeKnown)||Number(b.balance!==null)-Number(a.balance!==null)||a.date-b.date);
 for(let t of sorted){let e=effects(t),key=t.code||t.id;
  const families=t.kind==='receipt'||t.kind==='transferIn'?'credit':t.kind==='loanDraw'?'loanDraw':t.kind==='payment'||t.kind==='airtime'||t.kind==='withdrawal'||t.kind==='transferOut'||t.kind==='loanRepay'?'debit':t.kind;
  const mainKey=key+':main:'+families;const previous=used.get(mainKey);
  if(!t.excluded&&t.kind!=='review'&&t.kind!=='snapshot'){
   if(previous){
    if(previous.amount===t.amount&&previous.kind===t.kind&&previous.account===t.account&&!(previous.feeKnown&&t.feeKnown&&previous.fee!==t.fee)){duplicates.push({id:t.id,kept:previous.id,reason:'Same reference, action, account and amount'});e=effects({...t,excluded:true});e.creditCharges=t.creditCharge||0;if(t.draw){e.fulizaDraw=t.draw;e.walletIn=t.draw;}if(t.repay){e.fulizaRepay=t.repay;e.walletOut=t.repay;}}
    else if(previous.kind!==t.kind||previous.amount!==t.amount||previous.account!==t.account||(previous.feeKnown&&t.feeKnown&&previous.fee!==t.fee)){if(!previous.manual)blocked.add(mainKey);conflicts.push({id:t.id,kept:previous.id,reason:'Same reference has conflicting classifications or amounts; newer notification excluded until reviewed.'});e=effects({...t,excluded:true});}
   }else used.set(mainKey,t);
  }
  // Separate Fuliza notice and attached credit facts may repeat the same draw/repay.
  for(let component of ['fulizaDraw','fulizaRepay','creditCharges'])if(e[component]){let ck=key+':component:'+component,prev=used.get(ck);if(prev){if(prev.amount!==e[component])conflicts.push({id:t.id,reason:'Conflicting '+component+' amounts for one reference.'});let n=e[component];e[component]=0;if(component==='fulizaDraw')e.walletIn-=n;else if(component==='fulizaRepay')e.walletOut-=n;duplicates.push({id:t.id,component,reason:'Fuliza component already counted for reference'});}else used.set(ck,{amount:e[component],id:t.id});}
  entries.push({t,e,mainKey});
 }
 for(let entry of entries)if(blocked.has(entry.mainKey))entry.e=effects({...entry.t,excluded:true});
 entries.sort((a,b)=>a.t.date-b.t.date||a.t.id.localeCompare(b.t.id));return {entries,duplicates,conflicts};
}
function summary(rows,allRows=rows){let l=ledger(allRows),ids=new Set(rows.map(t=>t.id)),out={income:0,out:0,fees:0,review:rows.filter(t=>t.kind==='review'&&!t.excluded).length,spent:0,net:0,walletIn:0,walletOut:0,received:0,deposits:0,withdrawals:0,transferIn:0,transferOut:0,fulizaDraw:0,fulizaRepay:0,kcbDraw:0,kcbRepay:0,mshwariDraw:0,mshwariRepay:0,creditCharges:0,refunds:0,reversalOut:0,unknownFees:0};for(let {t,e} of l.entries)if(ids.has(t.id)){for(let k of Object.keys(e))if(k!=='spend')out[k]=(out[k]||0)+e[k];out.spent+=e.spend;}out.income=out.received;out.out=out.walletOut-out.fees;out.net=out.walletIn-out.walletOut;out.duplicates=l.duplicates.filter(d=>ids.has(d.id)).length;out.conflicts=l.conflicts.filter(d=>ids.has(d.id)).length;return out;}
// Build wallet checkpoints from related messages before reconciling. A
// separate Fuliza funding/repayment notice for the SAME reference belongs to
// the payment/receipt event, even if its SMS arrived a few seconds later.
function timeline(rows){
 const l=ledger(rows),groups=new Map(),family=t=>['payment','airtime','withdrawal','transferOut','loanRepay','reverseOut'].includes(t.kind)?'debit':['receipt','deposit','transferIn'].includes(t.kind)?'credit':t.kind;
 for(let entry of l.entries){const t=entry.t;let primary=t;
  if(t.code&&['fulizaDraw','fulizaRepay'].includes(t.kind)){
   const candidates=l.entries.filter(x=>x.t.code===t.code&&(t.kind==='fulizaDraw'?['payment','airtime','withdrawal','transferOut'].includes(x.t.kind):['receipt','deposit','transferIn','refund'].includes(x.t.kind))&&!x.t.excluded&&x.t.kind!=='review');
   candidates.sort((a,b)=>Math.abs(a.t.date-t.date)-Math.abs(b.t.date-t.date));if(candidates.length)primary=candidates[0].t;
  }
  const key=primary.code?primary.code+':'+family(primary):primary.id;
  if(!groups.has(key))groups.set(key,{date:primary.date,dated:primary.dated,precise:primary.precise,members:[],delta:0,debts:{fuliza:0,kcb:0,mshwari:0},snapshot:null});
  let g=groups.get(key);g.members.push(t);g.delta+=entry.e.walletIn-entry.e.walletOut;
  g.debts.fuliza+=entry.e.fulizaDraw-entry.e.fulizaRepay;g.debts.kcb+=entry.e.kcbDraw-entry.e.kcbRepay;g.debts.mshwari+=entry.e.mshwariDraw-entry.e.mshwariRepay;
  if(g.debts[t.debtService||t.service]!==undefined)g.debts[t.debtService||t.service]+=entry.e.creditCharges;
  if(t.dated&&!t.excluded&&t.balance!==null&&!/failed|unsuccessful|declined|cancelled|rejected|pending/i.test(t.body)&&(!g.snapshot||t.date>g.snapshot.date))g.snapshot=t;
 }
 return {groups:[...groups.values()].sort((a,b)=>a.date-b.date),ledger:l};
}
function accounts(rows){
 const {groups,ledger:l}=timeline(rows),wallet=groups.filter(g=>g.snapshot).sort((a,b)=>b.date-a.date),latestGroup=wallet[0]||null,latest=latestGroup?latestGroup.snapshot:null;
 let estimate=latest?latest.balance:null,uncertain=[],gaps=[];
 if(latest)for(let g of groups){if(g===latestGroup)continue;if(g.date>latestGroup.date){if(!g.dated){if(g.delta)uncertain.push(g.members[0].id);continue;}estimate+=g.delta;}else if(g.date===latestGroup.date&&g.delta)uncertain.push(g.members[0].id);}
 let previous=null,total=0;
 for(let g of groups){if(previous&&g.dated)total+=g.delta;if(g.snapshot){if(previous&&g.date>previous.date){let expected=previous.snapshot.balance+total;if(expected!==g.snapshot.balance)gaps.push({from:previous.snapshot.id,to:g.snapshot.id,expected,reported:g.snapshot.balance,difference:g.snapshot.balance-expected});}previous=g;total=0;}}
 let debt={};for(let service of ['fuliza','kcb','mshwari']){
  let snapshot=rows.filter(t=>(t.debtService||t.service)===service&&t.dated&&!t.excluded&&t.debtBalance!==null&&!/failed|declined|unsuccessful|rejected|pending/i.test(t.body)).sort((a,b)=>b.date-a.date)[0]||null;
  let savings=rows.filter(t=>t.service===service&&t.dated&&!t.excluded&&t.savingsBalance!==null).sort((a,b)=>b.date-a.date)[0]||null;
  let available=rows.filter(t=>t.service===service&&t.dated&&!t.excluded&&t.availableCredit!==null).sort((a,b)=>b.date-a.date)[0]||null;
  let debtEstimate=snapshot?snapshot.debtBalance:null,ambiguous=[];if(snapshot){let anchor=groups.find(g=>g.members.some(t=>t.id===snapshot.id));for(let g of groups){if(g===anchor||!g.dated)continue;if(g.date>anchor.date)debtEstimate+=g.debts[service];else if(g.date===anchor.date&&g.debts[service])ambiguous.push(g.members[0].id);}}
  debt[service]={snapshot,savings,available,estimate:debtEstimate,uncertain:ambiguous};
 }
 return {latest,estimate,uncertain,gaps,debt,duplicates:l.duplicates,conflicts:l.conflicts,negative:estimate!==null&&estimate<0};
}
function migrate(t){let n=parse(t.body,/\d{1,2}[\/-]\d{1,2}[\/-]\d{2}/.test(t.body)?t.date:undefined,t.sender||'');if(!n)return null;n.note=t.note||'';n.category=t.category||n.category;let oldFee=first(t.body,['transaction\\s+cost\\s*[,.:]?\\s*'])||0;if(Number.isSafeInteger(t.fee)&&t.fee!==oldFee){n.fee=t.fee;n.feeKnown=true;n.manual=true;}const original=amount(t.body);if(t.amount!==original&&t.amount>0){n.amount=t.amount;n.manual=true;}return n;}
const api={parse,summary,accounts,effects,ledger,timeline,kinds,cents,amount,migrate,norm};if(typeof module!=='undefined')module.exports=api;root.PesaParser=api;
})(typeof window==='undefined'?globalThis:window);
