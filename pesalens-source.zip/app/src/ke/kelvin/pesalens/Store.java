package ke.kelvin.pesalens;
import android.content.*;import android.database.*;import android.database.sqlite.*;import org.json.*;
public class Store extends SQLiteOpenHelper {
 public Store(Context c){super(c,"messages.db",null,2);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE sms (body TEXT, stamp INTEGER, sender TEXT, UNIQUE(body,stamp))");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){if(o<2){d.execSQL("ALTER TABLE sms RENAME TO sms_old");onCreate(d);d.execSQL("INSERT OR IGNORE INTO sms (body,stamp,sender) SELECT body,stamp,'MPESA' FROM sms_old");d.execSQL("DROP TABLE sms_old");}}
 public static boolean accepted(String sender,String body){if(sender==null)return false;String s=sender.replaceAll("[^A-Za-z0-9]","").toUpperCase(java.util.Locale.ROOT);return s.equals("MPESA")||s.equals("KCBMPESA")||s.equals("MSHWARI")||(s.equals("KCB")&&body!=null&&body.toUpperCase(java.util.Locale.ROOT).matches("(?s).*(KCB[ -]*M[ -]*PESA).*"));}
 public void add(String body,long stamp,String sender){ContentValues v=new ContentValues();v.put("body",body);v.put("stamp",stamp);v.put("sender",sender);getWritableDatabase().insertWithOnConflict("sms",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
 public String all(){JSONArray a=new JSONArray();try(Cursor c=getReadableDatabase().rawQuery("SELECT body,stamp,sender FROM sms ORDER BY stamp DESC",null)){while(c.moveToNext()){JSONObject o=new JSONObject();try{o.put("body",c.getString(0));o.put("stamp",c.getLong(1));o.put("sender",c.getString(2));a.put(o);}catch(Exception e){}}}return a.toString();}
}
