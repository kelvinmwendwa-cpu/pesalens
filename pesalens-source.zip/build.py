#!/usr/bin/env python3
"""Build the standalone Android APK. Internet is needed only to fetch build tools."""
import os, pathlib, shutil, subprocess, urllib.request, zipfile
root=pathlib.Path(__file__).resolve().parent
os.chdir(root)
tools=root/'tools';tools.mkdir(exist_ok=True)
def fetch(url,path):
    if not path.exists():
        print('Fetching',path.name,flush=True)
        urllib.request.urlretrieve(url,path)
for name,url in [('build.zip','https://dl.google.com/android/repository/build-tools_r35_linux.zip'),('platform.zip','https://dl.google.com/android/repository/platform-35_r02.zip')]:
    fetch(url,tools/name)
    if not (tools/'sdk'/('android-15' if name=='build.zip' else 'android-35')).exists():
        with zipfile.ZipFile(tools/name) as z:z.extractall(tools/'sdk')
fetch('https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar',tools/'ecj.jar')
bt=tools/'sdk/android-15';platform=tools/'sdk/android-35/android.jar'
for name in ['aapt','aapt2','d8','apksigner','zipalign']:os.chmod(bt/name,0o755)
for path in ['build/classes','build/dex','output']:pathlib.Path(path).mkdir(parents=True,exist_ok=True)
def run(*args):subprocess.run([str(x) for x in args],check=True)
run('java','-jar',tools/'ecj.jar','-8','-nowarn','-proc:none','-bootclasspath',str(platform)+os.pathsep+str(bt/'core-lambda-stubs.jar'),'-d','build/classes',*pathlib.Path('app/src').rglob('*.java'))
classes=list(pathlib.Path('build/classes').rglob('*.class'))
run(bt/'d8','--lib',platform,'--min-api','26','--output','build/dex',*classes)
run(bt/'aapt','package','-f','-M','app/AndroidManifest.xml','-S','app/res','-A','app/assets','-I',platform,'-F','build/unsigned.apk')
with zipfile.ZipFile('build/unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:z.write('build/dex/classes.dex','classes.dex')
run(bt/'zipalign','-f','4','build/unsigned.apk','build/aligned.apk')
key=tools/'pesalens-signing.p12'
if not key.exists():
    run('keytool','-genkeypair','-keystore',key,'-storetype','PKCS12','-storepass','pesalens-local-v1','-alias','pesalens','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=PesaLens Personal App','-noprompt')
run(bt/'apksigner','sign','--ks',key,'--ks-pass','pass:pesalens-local-v1','--out','output/PesaLens-v1.2.apk','build/aligned.apk')
run(bt/'apksigner','verify','--verbose','output/PesaLens-v1.2.apk')
print('Built output/PesaLens-v1.2.apk')
