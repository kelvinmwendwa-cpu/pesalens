const assert=require('node:assert/strict'),P=require('../app/assets/parser');
const p=(s,stamp)=>{let t=P.parse(s,stamp);assert(t,s);return t};let cases=0;
function fixture(s,fields){let t=p(s);for(let [k,v] of Object.entries(fields))assert.equal(t[k],v,t.body+' :: '+k);cases++;return t}
fixture('TJN1ABC001 Confirmed. Ksh1,500.00 sent to JANE DOE 0712345678 on 23/10/26 at 1:04 PM. New M-PESA balance is Ksh3,200.50. Transaction cost, Ksh13.00.',{kind:'payment',amount:150000,balance:320050,fee:1300,who:'JANE DOE 0712345678'});
fixture('TJN1ABC002 Confirmed.You have received Ksh2,000.00 from JOHN DOE 0712345678 on 23/10/26 at 9:10 AM. New M-PESA balance is Ksh5,000.00.',{kind:'receipt',amount:200000,balance:500000,feeKnown:false});
fixture('TJN1ABC003 Confirmed. Ksh250.00 paid to NAIVAS for account GROCERIES on 23/10/26 at 12:04 PM. New M-PESA balance is Ksh2,950.50. Transaction cost, Ksh0.00.',{kind:'payment',category:'Shopping',who:'NAIVAS'});
fixture('TJN1ABC004 Confirmed. Ksh100.00 bought airtime on 23/10/26 at 12:00 AM. New M-PESA balance is Ksh100.00. Transaction cost, Ksh0.00.',{kind:'airtime',amount:10000,feeKnown:true});
fixture('TJN1ABC005 Confirmed. Withdraw Ksh1,000.00 from Agent 123 on 23/10/26 at 12:00 PM. New M-PESA balance is Ksh500.00. Transaction cost, Ksh29.00.',{kind:'withdrawal',amount:100000,fee:2900});
fixture('TJN1ABC006 Confirmed. Ksh500.00 reversal processed. New M-PESA balance is Ksh1,000.00.',{kind:'review'});
fixture('TJN1ABC007 Confirmed. Ksh500.00 refunded and credited to your M-PESA account on 23/10/26 at 12:00 PM. New M-PESA balance is Ksh1,000.00.',{kind:'refund'});
fixture('TJN1ABC008 Failed. Ksh500.00 sent to JOHN.',{kind:'review'});
fixture('TJN1ABC009 Confirmed. Balance notification only. M-PESA balance is Ksh100.00.',{kind:'review'});
fixture('TJN1ABC010 Confirmed. Ksh2,000.00 deposited at AGENT on 23/10/26 at 3:00 PM. New M-PESA balance is Ksh2,500.00.',{kind:'deposit'});
fixture('TJN1ABC011 Confirmed. on 23/10/26 at 3:00 PM Give Ksh2,000.00 CASH to AGENT. New M-PESA balance is Ksh2,500.00.',{kind:'deposit',amount:200000});
fixture('Your Fuliza M-PESA amount is Ksh300.00. Access fee charged Ksh3.00. Total outstanding amount is Ksh303.00 to be repaid by 25/10/26.',{kind:'fulizaDraw',amount:30000,creditCharge:300,debtBalance:30300,dated:false});
fixture('Ksh303.00 has been used to repay Fuliza M-PESA on 23/10/26 at 10:00 AM. Outstanding Fuliza amount is Ksh0.00.',{kind:'fulizaRepay',amount:30300,debtBalance:0});
fixture('Your Fuliza M-PESA available limit is Ksh500.00. Outstanding amount is Ksh700.00 on 23/10/26 at 8:00 AM.',{kind:'snapshot',amount:0,availableCredit:50000,debtBalance:70000,balance:null});
fixture('Your Fuliza M-PESA daily maintenance fee of Ksh3.00 has been charged. Total outstanding amount is Ksh303.00 on 23/10/26 at 8:00 AM.',{kind:'creditCharge',creditCharge:300,amount:0});
fixture('Your KCB M-PESA loan of Ksh1,000.00 has been credited to your KCB M-PESA account on 23/10/26 at 10:59 AM. Loan amount due is Ksh1,088.00. KCB M-PESA account balance is Ksh1,000.00.',{kind:'loanDraw',account:'bank',amount:100000,balance:null,debtBalance:108800,savingsBalance:100000});
fixture('TJN1ABC012 Confirmed. You have received Ksh1,000.00 from KCB M-PESA on 23/10/26 at 11:00 AM. New M-PESA balance is Ksh1,197.00. Transaction cost, Ksh0.00.',{kind:'transferIn',service:'kcb',amount:100000});
fixture('TJN1ABC013 Confirmed. Ksh200.00 sent to KCB M-PESA on 23/10/26 at 12:00 PM. New M-PESA balance is Ksh997.00. Transaction cost, Ksh0.00.',{kind:'transferOut',service:'kcb'});
fixture('TJN1ABC014 Confirmed. Ksh300.00 paid to KCB M-PESA loan repayment 522559 on 23/10/26 at 12:00 PM. New M-PESA balance is Ksh697.00. Transaction cost, Ksh0.00.',{kind:'loanRepay',account:'wallet',service:'kcb'});
fixture('Your KCB M-PESA loan has been repaid Ksh300.00 from your KCB M-PESA account on 23/10/26 at 12:00 PM. Outstanding loan balance is Ksh788.00.',{kind:'loanRepay',account:'bank',amount:30000,debtBalance:78800});
fixture('Your KCB M-PESA loan has been repaid Ksh300.00 on 23/10/26 at 12:00 PM. Outstanding loan balance is Ksh788.00.',{kind:'review',account:'unknown'});
fixture('Ksh200.00 transferred from your KCB M-PESA account to your M-PESA account on 23/10/26 at 12:00 PM.',{kind:'review'});
fixture('TJN1ABC015 Confirmed. Your KCB M-PESA loan of Ksh1000.00 has been credited to your M-PESA account on 23/10/26 at 12:00 PM. New M-PESA balance is Ksh1000.00.',{kind:'loanDraw',account:'wallet'});
fixture('Your KCB M-PESA loan of Ksh1000.00 was approved on 23/10/26 at 12:00 PM.',{kind:'review'});
fixture('Your KCB M-PESA loan limit is Ksh3000.00 on 23/10/26 at 12:00 PM.',{kind:'review'});
fixture('TJN1ABC016 Confirmed. Ksh100.00 sent to M-SHWARI account on 23/10/26 at 1:00 PM. New M-PESA balance is Ksh900.00.',{kind:'transferOut',service:'mshwari'});
fixture('TJN1ABC017 Confirmed. Ksh100.00 deducted from your wallet following reversal on 23/10/26 at 1:00 PM.',{kind:'reverseOut'});
fixture('Your KCB M-PESA account balance is Ksh5,000.00 on 23/10/26 at 1:00 PM.',{kind:'snapshot',balance:null,savingsBalance:500000});
fixture('TJN1ABC018 Confirmed. You have received Ksh1,000.00 from KCB M-PESA on 23/10/26 at 1:00 PM. Ksh300.00 has been used to repay Fuliza M-PESA. Outstanding Fuliza amount is Ksh0.00. New M-PESA balance is Ksh700.00.',{kind:'transferIn',service:'kcb',debtService:'fuliza',repay:30000});
assert.equal(P.parse('Hello, promotional message'),null);assert.equal(P.parse('KCB M-PESA OTP 1234 for Ksh500'),null);
assert.equal(P.cents('0.01'),1);assert.equal(P.cents('1.20'),120);assert.equal(P.cents('12.345'),null);assert.equal(P.cents('-1'),null);
// A coherent history covering overdraft funding, subsequent repayment, a bank
// loan then transfer, cash out, savings, and a bank-loan repayment.
const messages=[
'TST1ABC001 Confirmed. You have received Ksh100.00 from JANE on 23/10/26 at 8:00 AM. New M-PESA balance is Ksh100.00. Transaction cost, Ksh0.00.',
'TST1ABC002 Confirmed. Ksh500.00 paid to SHOP on 23/10/26 at 9:00 AM. Fuliza M-PESA amount is Ksh406.00. New M-PESA balance is Ksh0.00. Transaction cost, Ksh6.00.',
'TST1ABC002 Your Fuliza M-PESA amount is Ksh406.00. Access fee charged Ksh4.06. Total outstanding amount is Ksh410.06 on 23/10/26 at 9:00 AM.',
'TST1ABC003 Confirmed. You have received Ksh1,000.00 from JOHN on 23/10/26 at 10:00 AM. Ksh410.06 has been used to repay Fuliza M-PESA. Outstanding Fuliza amount is Ksh0.00. New M-PESA balance is Ksh589.94. Transaction cost, Ksh0.00.',
'TST1ABC003 Ksh410.06 has been used to repay Fuliza M-PESA on 23/10/26 at 10:00 AM. Outstanding Fuliza amount is Ksh0.00.',
'Your KCB M-PESA loan of Ksh1000.00 has been credited to your KCB M-PESA account on 23/10/26 at 10:59 AM. Loan amount due is Ksh1088.00. KCB M-PESA account balance is Ksh1000.00.',
'TST1ABC004 Confirmed. You have received Ksh1000.00 from KCB M-PESA on 23/10/26 at 11:00 AM. New M-PESA balance is Ksh1589.94. Transaction cost, Ksh0.00.',
'TST1ABC005 Confirmed. Withdraw Ksh200.00 from AGENT on 23/10/26 at 12:00 PM. New M-PESA balance is Ksh1360.94. Transaction cost, Ksh29.00.',
'TST1ABC006 Confirmed. Ksh100.00 sent to KCB M-PESA on 23/10/26 at 1:00 PM. New M-PESA balance is Ksh1260.94. Transaction cost, Ksh0.00.',
'TST1ABC007 Confirmed. Ksh300.00 paid to KCB M-PESA loan repayment 522559 on 23/10/26 at 2:00 PM. New M-PESA balance is Ksh960.94. Transaction cost, Ksh0.00.',
'TST1ABC008 Confirmed. Ksh60.00 sent to JANE on 23/10/26 at 3:00 PM. New M-PESA balance is Ksh900.94. Transaction cost, Ksh0.00.'
].map(s=>p(s));
const sum=P.summary(messages),accounts=P.accounts(messages);
for(let [k,v] of Object.entries({received:110000,spent:59500,fees:3500,withdrawals:20000,transferIn:100000,transferOut:10000,fulizaDraw:40600,fulizaRepay:41006,kcbDraw:100000,kcbRepay:30000,creditCharges:406,net:90094,walletIn:250600,walletOut:160506}))assert.equal(sum[k],v,k);
assert.equal(accounts.latest.balance,90094);assert.equal(accounts.estimate,90094);assert.equal(accounts.gaps.length,0,JSON.stringify(accounts.gaps));assert.equal(accounts.debt.fuliza.snapshot.debtBalance,0);assert.equal(accounts.debt.kcb.snapshot.debtBalance,108800);
assert.equal(P.summary(messages.slice(1,3),messages).fulizaDraw,40600);
const missing=messages.filter(t=>t.code!=='TST1ABC005');assert(P.accounts(missing).gaps.length>0);
const after=p('TST1ABC009 Confirmed. Ksh10.00 sent to JANE on 23/10/26 at 4:00 PM. Transaction cost, Ksh0.00.');assert.equal(P.accounts([...messages,after]).estimate,89094);
const duplicate=p(messages[0].body.replace('Confirmed.','Confirmed. '));assert.equal(duplicate.id,messages[0].id);
// Related duplicated acknowledgement with same reference must not count twice.
const alternate=p(messages[0].body.replace('JANE on','JANE DOE on'));assert.equal(P.summary([...messages,alternate]).walletIn,sum.walletIn);
const conflict=p(messages[0].body.replace('Ksh100.00 from','Ksh200.00 from'));assert(P.summary([messages[0],conflict]).conflicts>0);assert.equal(P.summary([messages[0],conflict]).walletIn,0);
const edited={...messages[0],manual:true};assert.equal(P.summary([edited,conflict]).walletIn,10000);
const tiny=Array.from({length:100},(_,i)=>({...messages[0],id:'SMS'+i,code:'TEST'+i,amount:1,balance:null}));assert.equal(P.summary(tiny).walletIn,100);
console.log('Passed '+cases+' parser fixtures; exact-cent math; coherent 11-message loan/overdraft ledger; component deduplication; conflicts; missing-SMS balance gaps; snapshot and later-movement calculations.');
module.exports={messages};
// A due date must not be mistaken for the transaction timestamp.
assert.equal(p('Your Fuliza M-PESA amount is Ksh10.00. Outstanding amount is Ksh10.10 to be repaid by 30/10/26.').dated,false);
fixture('TJN1ABC020 Confirmed. New M-PESA balance is Ksh900.00. Ksh100.00 sent to JANE on 23/10/26 at 1:00 PM. Transaction cost, Ksh0.00.',{kind:'payment',amount:10000,balance:90000});
fixture('Ksh303.00 has been used to fully repay Fuliza M-PESA on 23/10/26 at 10:00 AM.',{kind:'fulizaRepay',amount:30300});
fixture('Your KCB M-PESA loan of Ksh1000.00 has been credited to your KCB M-PESA account on 23/10/26 at 1:00 PM. Loan fee of Ksh20.00. Loan interest of Ksh50.00. Amount due is Ksh1070.00.',{kind:'loanDraw',amount:100000,creditCharge:7000,debtBalance:107000});
fixture('Your KCB M-PESA loan of Ksh1000.00 has been credited to your KCB M-PESA account on 23/10/26 at 1:00 PM. Loan fee of Ksh20.00. Loan interest of Ksh50.00. Total loan charges of Ksh70.00. Amount due is Ksh1070.00.',{kind:'loanDraw',creditCharge:7000});
const separate=messages.map(t=>t.code==='TST1ABC002'&&t.kind==='payment'?p(t.body.replace(' Fuliza M-PESA amount is Ksh406.00.','')):t);
assert.equal(P.accounts(separate).gaps.length,0);assert.equal(P.summary(separate).walletIn,250600);
const receiptSeparate=messages.map(t=>t.kind==='receipt'&&t.repay>0?p(t.body.replace(' Ksh410.06 has been used to repay Fuliza M-PESA.','')):t);
assert.equal(P.accounts(receiptSeparate).gaps.length,0);assert.equal(P.summary(receiptSeparate).walletOut,160506);
assert.equal(P.accounts(messages).debt.kcb.estimate,78800);
// Native SMS arrival can lag its actual, reference-linked financial event.
let lagged=separate.map(t=>t.kind==='fulizaDraw'?{...t,date:t.date+10000,precise:true}:t);assert.equal(P.accounts(lagged).gaps.length,0);
// A richer duplicate can contribute funding information without repeating the purchase.
const baseOnly=p(messages[1].body.replace(' Fuliza M-PESA amount is Ksh406.00.',''));
assert.equal(P.summary([baseOnly,messages[1]]).walletIn,40600);assert.equal(P.summary([baseOnly,messages[1]]).walletOut,50600);
console.log('Additional tests passed: '+cases+' fixtures total; due-date isolation; balance-first text; component charges; separate/delayed credit notices; richer duplicate merge; later debt estimate.');
const undated='Your Fuliza M-PESA amount is Ksh10.00. Total outstanding amount is Ksh10.10.';
assert.notEqual(p(undated,1792738800000).id,p(undated,1792742400000).id);
console.log('Identical reference-less native messages at distinct SMS timestamps retain distinct identities.');
const netLoan=fixture('TJN1ABC021 Confirmed. Your KCB M-PESA loan of Ksh1000.00 has been credited to your M-PESA account on 23/10/26 at 1:00 PM. Net proceeds is Ksh912.00. Loan fee of Ksh88.00.',{kind:'loanDraw',amount:100000,walletProceeds:91200,creditCharge:8800});
assert.equal(P.summary([netLoan]).walletIn,91200);assert.equal(P.summary([netLoan]).kcbDraw,100000);assert.equal(P.summary([netLoan]).spent,0);
fixture('TJN1ABC022 Confirmed. Your KCB M-PESA loan of Ksh1000.00 has been credited to your M-PESA account on 23/10/26 at 1:00 PM. Loan fee of Ksh88.00 deducted upfront.',{kind:'review'});
console.log('Net loan proceeds vs principal and withheld-fee ambiguity passed; '+cases+' parser fixtures total.');
