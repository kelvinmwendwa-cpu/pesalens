# PesaLens 1.2 — phone layout and refresh

An independent offline Android app for Kelvin. Android 8.0 and newer. No M-Pesa PIN, account login or internet permission is used.

## Install the update
Open PesaLens-v1.2.apk and install it over the existing PesaLens app. This release uses the same application ID and signing key as 1.0, so Android can update the app while retaining its data. Export a backup before changing or uninstalling an installed app. Open Import and scan the inbox again to pick up supported bank messages that version 1.0 did not read.

If Android blocks SMS: Settings → Apps → Manage apps → PesaLens → More / three dots → Allow restricted settings, if that option is offered, then App permissions → SMS → Allow. This is controlled by Android; an APK update does not override restricted permissions. You can instead paste complete messages. Separate messages without references using a blank line.

## Version 1.2 layout and refresh
- Responsive layout checked from 320 to 430 CSS pixels and landscape. Content scrolls between the header and bottom navigation; it no longer runs behind the navigation.
- Summary cards stack on narrow phones. Long names, amount rows and labels wrap inside the available width.
- Transaction details fit the available viewport, scroll vertically and keep a close control in the detail header. The layout responds to changes in available viewport height such as the keyboard. Pinch zoom is no longer disabled.
- Header Refresh rescans the SMS inbox if read permission is already granted. Without permission it reloads saved messages and totals and explains how to import new messages. It does not bypass Android permissions or retrieve a live M-Pesa balance.
- Existing accounting rules, history, local storage, backups and signature identity are retained.

## Accounting features retained
- Recognises supported Fuliza use, automatic repayments, debt snapshots and explicitly assessed credit charges.
- Separates KCB M-Pesa loans credited to the bank account from transfers into the M-Pesa wallet, savings transfers out, and loan repayments. The same treatment covers supported M-Shwari wording.
- Shows received money, wallet credits, wallet debits, spending, cash movement and fees as separate quantities.
- Adds Credit & math: credit borrowed/repaid, latest reported debt, estimates after later tracked activity, reported savings, available credit, wallet equations, reconciliation gaps, reference conflicts and duplicate components.
- Allows correction of kind, account, provider, amounts, fees, net loan wallet proceeds, Fuliza funding/repayment inside another message, assessed charges, all balance snapshots, category, note and original date. Messages can be excluded as duplicates; the original SMS text remains unchanged.
- Preserves original v1 state in a local pre-update copy and migrates the saved messages, notes, categories and identifiable amount/fee corrections. Unedited SMS can be reparsed with the new rules. Both v1 and v2 JSON backups can be restored.
- Preserves search, date filters, budgets, charts, top spending recipients, CSV export, JSON backup, optional phone screen-lock check on launch, screenshot blocking and offline storage.
- Reads supported sender IDs MPESA/M-PESA, KCBMPESA/KCB-MPESA and MSHWARI. Generic KCB messages are read only when their body explicitly mentions KCB M-PESA. SMS sender names are inputs to parsing, not authenticated proof that a message is genuine.

## Exact accounting rules
All currency arithmetic uses integer Kenya-shilling cents. No interest rate or tariff is hardcoded.

| Event | M-Pesa wallet | Spending / received money |
| --- | --- | --- |
| Ordinary received money | Credit | Received money, not necessarily earned income |
| Cash deposit | Credit | Cash movement, not income |
| Payment, money sent or airtime | Debit | Spending |
| Cash withdrawal | Debit | Cash movement; its wallet fee counts as spending |
| Transfer to/from KCB M-Pesa or savings | Debit/credit | Transfer, not spending or income |
| Loan credited to KCB/savings account | No wallet change | Borrowed principal recorded separately |
| Explicit loan disbursement into wallet | Credit at stated net proceeds, if provided | Borrowing, not income |
| Fuliza shortfall funding | Funding credit for the wallet equation | Borrowing, not income or spending |
| Loan/Fuliza repayment | Debit only if paid from wallet | Repayment, not a second purchase |
| Transaction cost stated in SMS | Wallet debit | Known wallet fee, counted once |
| Credit interest/access/maintenance charge assessed to debt | No additional wallet debit | Assessed charge shown separately; not deducted again |
| Refund/reversal received | Credit | Refund shown separately; spending displayed before refunds |
| Limit, available credit or balance enquiry | No movement | Information only |

Wallet movement = confirmed credits − confirmed debits. Remaining wallet cash starts from a reported M-Pesa balance, then adjusts for later tracked movements. The opening balance of a selected date range is not assumed to be zero. A KCB savings balance or an unused Fuliza limit never becomes wallet cash. Loan principal and the net loan amount credited to the wallet can differ; the app stores both when explicitly stated. Where upfront deductions are mentioned but the net wallet proceeds are unclear, the message needs review.

Monthly budget now measures spending: payments, airtime, sent money and known wallet transaction fees. Cash withdrawal principal, savings transfers and loan repayment principal are excluded. These movements remain visible in wallet debits. Subsequent cash purchases are outside SMS tracking.

## Duplicate and ordering controls
Exact normalised message duplicates are skipped. Reference-less native messages without a stated date retain distinct identities when their source SMS timestamps differ. Messages with the same exact reference, action, account and amount are deduplicated. Complementary Fuliza funding or repayment is retained without duplicating the payment/receipt. Funding and repayment notices sharing a reference are grouped with their related financial event for balance reconciliation, even if notification delivery is delayed. Conflicting reference amounts or classifications are excluded pending review; a manual correction takes precedence. No fuzzy matching of unrelated amounts or names is used. Reference-less bank acknowledgements that could repeat a wallet confirmation need review.

## Limits and review
The parser recognises specific English SMS patterns. No real customer SMS sample was provided for this update: tests use synthetic examples, so this is not a guarantee of coverage of every Safaricom/KCB template. Failed, pending, unclear, unsupported and ambiguous messages do not produce guessed movements. Some unrelated or unsupported messages are skipped. Dates in repayment deadlines are not treated as transaction dates. Undated pasted messages appear under All time and need their original date added before date-filtered summaries include them. Use one wallet per app.

Reported balances are snapshots, not live account queries. Missing SMS, unreported fees, changed formats, unlinked notices and coarse timestamps can leave gaps. Debt estimates after the last snapshot use only known later activity and may omit accrued charges. Negative estimates, conflicts and unexplained differences require review; the app does not silently patch them. Repayments can include principal and charges: no principal/interest split is invented. Manually excluded messages do not affect calculations. Android/phone vendor restrictions, denied SMS access and force-stop can interrupt automatic collection.

## Privacy and backup
No financial data is uploaded. The app has no internet permission, advertising, analytics or payment capability. Local Android storage is private to the app; automatic Android backups are disabled. CSV/JSON exports contain financial data in readable, unencrypted form. Back up before uninstalling or clearing app storage. Deleting saved app data does not delete original SMS. Revoke SMS permissions if you want to stop new collection. Screen lock is checked on app launch, not every switch between apps.

## Validation
- Responsive layout tests cover 320/360/393/430 CSS pixel widths, landscape, large amounts, long unbroken names, all six views, detail form scrolling, short viewport and refresh behaviour with and without SMS permission. These are browser simulations; physical Redmi 14C display/keyboard behaviour has not been device-tested.
- 35 synthetic parser fixtures plus exact-cent, loan/principal/net-proceeds, fee, snapshot, due-date, reference-conflict and duplicate-component checks.
- A coherent 11-message scenario reconciles an opening receipt, Fuliza-funded purchase, Fuliza repayment, KCB bank loan, wallet transfer, cash withdrawal, savings transfer, loan repayment and payment to the cent.
- Tests cover separate/delayed Fuliza notices, richer acknowledgements, missing-message detection, newer debt/wallet estimates and distinct repeated native SMS timestamps.
- Mobile UI checks at 360, 393 and 430 CSS pixels cover all six views, import, correction/reset, search, budget, reload persistence, CSV, full v2 backup round-trip, malformed/duplicate restore and v1 migration.
- Java compilation, DEX packaging, zip integrity and APK v2/v3 signature verification. Signing certificate matches version 1.0.
- No physical Android phone or Android emulator was used here. Native installation, Android permission grants, SMS receipt, file picker, device-lock interaction and Android SQLite migration still require device verification.

## Source and rebuild
This archive contains the source, tests and build.py. The private signing key is included so future updates can retain the installed app's identity. Keep this archive private. Run `python3 build.py` on Linux with Python 3 and Java 17+. It fetches Android SDK Build Tools 35.0.0, Android 35 platform and Eclipse ECJ 3.38.0, and uses aapt, ECJ, d8, zipalign and apksigner. No third-party runtime libraries are bundled in the APK. Run parser tests with `node tests/parser.test.js`; browser UI tests require Playwright and the Chrome executable path configured in tests/ui.test.cjs.

Background product references used to distinguish account movements (no tariff values copied into the app):
- KCB M-Pesa product and transfer description: https://ke.kcbgroup.com/products/kcb-mpesa
- KCB loan destination and movement to M-Pesa: https://ke.kcbgroup.com/for-you/get-a-loan/mobile/kcb-m-pesa-loan
- NCBA description of automatic Fuliza recovery: https://ncbagroup.com/ke/personal-loans/
